import UIKit



let seconds = 180
let NotDone = "It's not done yet! Check back later"
let Done = "Ding ding ding! Your egg is done!"



 for index in 1...seconds {
    if index == 180 {  print(index , Done)
        
}
    else { print(index , NotDone)
}
   sleep(1)
     // makes the code display every second so its not instant
}
